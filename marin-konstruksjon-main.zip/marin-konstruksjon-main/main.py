import numpy as np
import lesinput
import funksjoner.prosent as pm
from lengder import lengder
from funksjoner.boyestivhet import boyestivhet
from funksjoner.lastvektor import fim, elemlast_til_syslast, knutmom
from funksjoner.stivhetsmatrise import stivmat
from funksjoner.grensebetingelser import bc
from funksjoner.boyespenning import boyespenning
from funksjoner.boyemoment import boyemoment
from funksjoner.endemoment import endemoment_per_elem, endemoment
from funksjoner.skjaer import skjaer




def main(filename):

    #Leser inputdata
    npunkt, punkt, nelem, elemkonn, tvsnitt, e_mod, nnode_loads, KNUTELASTER, nel_loads, ELEMENTLASTER, n_point_loads, PUNKTLASTER, n_trap_loads, TRAPESLASTER, n_flyt, FLYTESPENNING, GEOMETRI = lesinput.lesinput(filename)

    #returnerer en dict med alle elemntlaster, punktlaster og trapeslaster med elementet som nøkkel
    element_q = {i: 0.0 for i in range(nelem)}
    if ELEMENTLASTER and ELEMENTLASTER.get("elem_ids") is not None and ELEMENTLASTER.get("elem_ids").size:
        for eid, q in zip(ELEMENTLASTER["elem_ids"], ELEMENTLASTER["q"]):
            element_q[int(eid)] += float(q)

    punktl_pr_elem = {i: [] for i in range(nelem)}
    if PUNKTLASTER and PUNKTLASTER.get("elem_ids").size:
        for eid, q, afr in zip(PUNKTLASTER["elem_ids"], PUNKTLASTER["q"], PUNKTLASTER["avstandsforhold"]):
            punktl_pr_elem[int(eid)].append((float(q), float(afr)))

    trapes_pr_elem = {i: None for i in range(nelem)}
    if TRAPESLASTER and TRAPESLASTER.get("elem_ids").size:
        for eid, q1, q2 in zip(TRAPESLASTER["elem_ids"], TRAPESLASTER["q1"], TRAPESLASTER["q2"]):
            trapes_pr_elem[int(eid)] = (float(q1), float(q2))

    #Beregner elementlengder, som array
    elemlen = lengder(punkt, elemkonn)

    # Beregner bøyestivhet for alle elementer
    EI = boyestivhet(tvsnitt, e_mod, geometri = lesinput.GEOMETRI)  # bruker E=210 GPa for stål




    # -------------------Bygger systemlastvektor------------------
    R = np.zeros(npunkt, dtype=float)   #  dtype=float (tall med desimaler)
    
    # Arrays for fastinnspenningsmomenter per element (brukes senere i boyemoment)
    M_fim_i = np.zeros(nelem, dtype=float)
    M_fim_j = np.zeros(nelem, dtype=float)

    # går gjennom alle element og regner ut fastinspenningsmoment fra lastdefinisjonene og lager lastvektoren ut i fra disse
    # Antar at vi har en struktur som for hvert element e har q_e og evt. liste med punktlaster
    for e in range(nelem):
        L = elemlen[e]

        q_e = element_q.get(e)
        punktl_e = punktl_pr_elem.get(e, [])
        trapesl_e = trapes_pr_elem.get(e)

        # Beregner elementlastvektor S_fim m/fastinnspenningsmomenter for elementer med ytre last
        S_fim = fim(L, q=q_e, punktlaster=punktl_e, trapeslast=trapesl_e)
        
        # Adderer elementlastvektor S_fim inn i systemlastvektor R vha. elementkonnektivitet
        R = elemlast_til_syslast(R, S_fim, elemkonn, e)
        # Lagre fastinnspenningsmomenter (antatt S_fim[0], S_fim[1] = M_fim_i, M_fim_j)
        M_fim_i[e] = S_fim[0]
        M_fim_j[e] = S_fim[1]

    # Påsatte knutepunktsmomenter
    # Adderer knutepunktsmoment inn i systemlastvektor R
    if KNUTELASTER:                               
        R = knutmom(R, knut_momenter=KNUTELASTER)

    #--------Bygger systemstivhetsmatrisen ved å innaddere elementstivhetsmatriser vha. elementkonnektivitet------
    K = stivmat(nelem, npunkt, elemkonn, elemlen, EI)

    # Innfører grensebetingelser
    # Lag funksjonen selv basert på valgt metode for innføring av grensebetingelser
    Kn, Rn = bc(punkt, npunkt, K, R)
    print("\nSystemstivhetsmatrise K:\n")
    print(Kn)
    print("\nSystemlastvektor R:\n")
    print(Rn)

    #------------------regner ut rotasjonene med å løse ligningssystemet------------
    rot = np.linalg.solve(Kn, Rn)
    #legger rotasjonene i to arrays, en for rotasjoner i ende 1 av elementene og en for rotasjoner i ende 2
    def thetas_from_rot(rot, elemkonn):
        sys_i = elemkonn[:, 0].astype(int)
        sys_j = elemkonn[:, 1].astype(int)
        theta_i = rot[sys_i]
        theta_j = rot[sys_j]
        return theta_i, theta_j
    theta_i, theta_j = thetas_from_rot(rot, elemkonn)

    #-------------------Beregner momentverdier for alle element ved endene ----------------
    

    M_i, M_j  = endemoment(nelem, elemkonn, theta_i, theta_j, M_fim_i, M_fim_j, EI, elemlen)
    print("\nMomentverdier ved i-ende for alle elementer:\n")
    print(M_i)  
    print("\nMomentverdier ved j-ende for alle elementer:\n")
    print(M_j)

    #-----------------Beregner midtmoment under fordelt last og undermoment for punktlast-------
    M_under,M_midt = boyemoment(
        nelem, punkt, elemkonn, tvsnitt, e_mod, GEOMETRI,
        n_point_loads, PUNKTLASTER, nel_loads, ELEMENTLASTER,
        theta_i, theta_j,
        M_fim_i, M_fim_j,
        boyestivhet_fn=boyestivhet,
        endemoment_fn=endemoment_per_elem,
    )
    print("Momentverdier ved midtpunkt under fordelt last for alle elementer med fordelt last:\n")
    print(M_midt)
    print(M_under)

    #-----------------Beregner skjærkraftverdier for alle element ved endene------------------------
    Q = skjaer(nelem,
    elemkonn,
    elemlen,
    element_q=element_q,
    punktl_pr_elem=punktl_pr_elem,
    trapes_pr_elem=trapes_pr_elem,
    M_i=M_i,
    M_j= M_j,)

    print("Skjærkraftverdier for tegning av Q-diagram (for hånd):")
    print(Q)

    #--------------Beregner bøyespenning for alle element ved endene, og ved midtpunkt for fordelt last og under punktlaster--------
    sigma_M = boyespenning(
    punkt=punkt,
    elemkonn=elemkonn,
    tvsnitt=tvsnitt,
    e_mod=e_mod,
    GEOMETRI=GEOMETRI,
    n_point_loads=n_point_loads,
    PUNKTLASTER=PUNKTLASTER,
    nel_loads=nel_loads,
    ELEMENTLASTER=ELEMENTLASTER,
    theta_i=theta_i, theta_j=theta_j, M_fim_i=M_fim_i, M_fim_j=M_fim_j,
    boyestivhet_fn=boyestivhet,
    boyemoment_fn=boyemoment,
    endemoment_fn=endemoment_per_elem,
)
    print("Bøyespenninger:\n")
    print(sigma_M)

    #Printer momentverdier for alle elementer
    print("Momentverdier for tegning av M-diagram (for hånd):\n")
    print("M_i , M_ midt under fordelt last, M under punktlast, M_j")
    print(M_i ,M_midt, M_under, M_j)

    #prosentberegninger
    prosent = pm.prosent_per_element(sigma_M, FLYTESPENNING)           
    grupper = pm.gruperer_elementgrupper(elemkonn, punkt)       
    gruppe_prosent = pm.prosent_per_gruppe(prosent, grupper)            

    print("Prosent per element:", prosent)
    print("Max prosent per gruppe:", gruppe_prosent)
 
    
    return R, K, Kn, Rn, rot, sigma_M, M_midt, M_under, M_i, M_j


R, K, Kn, Rn, rot, sigma_M, M_midt, M_under,M_i, M_j = main("input.txt")


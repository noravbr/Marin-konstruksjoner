import numpy as np

# Elementstivhetsmatrise for uforskyvelig ramme (kun rotasjoner)
def ke_uforskyvelig(EI, L):
    """Elementstivhetsmatrise for uforskyvelig ramme (kun rotasjoner)."""
    return (EI / L) * np.array([[4.0, 2.0],
                                [2.0, 4.0]], dtype=float)

# Bygger global stivhetsmatrise K ved assembly av elementmatriser
def stivmat(nelem, npunkt, elemkonn, elemlen, EI):
    
    K = np.zeros((npunkt, npunkt), dtype=float)
    for e in range(nelem):
        i_node, j_node = int(elemkonn[e, 0]), int(elemkonn[e, 1])
        ke = ke_uforskyvelig(EI[e], elemlen[e])
        K[i_node, i_node] += ke[0, 0]
        K[i_node, j_node] += ke[0, 1]
        K[j_node, i_node] += ke[1, 0]
        K[j_node, j_node] += ke[1, 1]
    return K

# funksjoner/prosent.py (enkel versjon)
import numpy as np

 # Beregner prosent av flytespenning per element basert på bøyespenning.
def prosent_per_element(sigma_M, flytespenning):
    if flytespenning == 0:
        raise ValueError("flytespenning kan ikke være 0")
    sigma = sigma_M["sigma"] if isinstance(sigma_M, dict) else sigma_M
    sigma = np.asarray(sigma, float)
    #Finner største absolutt verdi spenning per element
    max_abs = np.abs(sigma) if sigma.ndim == 1 else np.max(np.abs(sigma), axis=1)
    return (max_abs / float(flytespenning)) * 100.0

import numpy as np

def gruperer_elementgrupper(elemkonn, punkt, tol=1e-9):
    #Grupperer elementer etter orientering og posisjon.
    #Horisontale bjelker grupperes etter høydenivå (y-verdi)
    #Vertikale bjelker grupperes etter søyleposisjon (x-verdi)
    #Skrå bjelker får hver sin egen gruppe
    ek = np.asarray(elemkonn, int)
    pk = np.asarray(punkt, float)
    grupper = {}

    for e in range(ek.shape[0]):
        i, j = ek[e, 0], ek[e, 1]
        xi, yi = pk[i, 0], pk[i, 1]
        xj, yj = pk[j, 0], pk[j, 1]
        dx = xj - xi
        dy = yj - yi

        if abs(dy) <= tol and abs(dx) > tol:
            # Horisontal: grupper etter høydenivå (bruk midtpunktets y-verdi)
            y_level = round((yi + yj) / 2, 6)
            key = f"horisontal_y={y_level}"
        elif abs(dx) <= tol and abs(dy) > tol:
            # Vertikal: grupper etter søyleposisjon (bruk midtpunktets x-verdi)
            x_pos = round((xi + xj) / 2, 6)
            key = f"vertikal_x={x_pos}"
        else:
            # Skrå: egen gruppe per element
            key = f"skrå_elem_{e}"

        # legg til elementet i riktig gruppe
        grupper.setdefault(key, []).append(e)

    return grupper


def prosent_per_gruppe(prosent, grupper):
    #Finner maks prosent per gruppe av elementer
    p = np.asarray(prosent, float)
    return {g: (float(np.max(p[idx])) if idx else 0.0) for g, idx in grupper.items()}

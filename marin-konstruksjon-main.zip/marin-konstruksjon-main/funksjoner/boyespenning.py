import numpy as np
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
import lesinput as LI
from lengder import lengder
# Beregner I for ror og I-profiler W = I/c
def _W_ror(D, t):
    d = D - 2.0*t
    I = (np.pi/64.0) * (D**4 - d**4)
    return I / (D/2.0)

def _W_I(h, tw, bf, tf):
    hw = h - 2.0*tf
    I_web = (tw * hw**3) / 12.0
    A_fl = bf * tf
    y = (h/2.0 - tf/2.0)
    I_flenser = 2.0 * ((bf * tf**3)/12.0 + A_fl * y**2)
    Ixx = I_web + I_flenser
    return Ixx / (h/2.0)

#beregner W for alle elementer i modellen
def _seksjonsmodul_per_element(tvsnitt, GEOMETRI):
    W = np.zeros_like(tvsnitt, dtype=float)
    for e, tid in enumerate(tvsnitt.astype(int)):
        params = GEOMETRI[tid]["params"]
        if len(params) == 2:                    # rør: [D, t]
            W[e] = _W_ror(float(params[0]), float(params[1]))
        elif len(params) == 4:                  # I: [h, tw, bf, tf]
            h, tw, bf, tf = map(float, params[:4])
            W[e] = _W_I(h, tw, bf, tf)
        else:
            raise ValueError(f"Ukjent tverrsnittdef for type_id={tid}: {params}")
        if not np.isfinite(W[e]) or W[e] <= 0:
            raise ValueError(f"Ugyldig W for element {e} (type {tid}).")
    return W
#beregner bøyespenning i tre snitt per element ved bruk av midt/under-moment og endemomenter
# σ = M / W
def boyespenning(
    punkt,
    elemkonn,
    tvsnitt,
    e_mod,
    GEOMETRI,
    n_point_loads,
    PUNKTLASTER,       # {"elem_ids": int[], "q": float[], "avstandsforhold": float[]}
    nel_loads,
    ELEMENTLASTER,     # {"elem_ids": int[], "q": float[]}
    theta_i=None, theta_j=None, M_fim_i=None, M_fim_j=None,
    boyestivhet_fn=None,
    boyemoment_fn=None,  
    endemoment_fn=None,
    ):


    nelem = elemkonn.shape[0]

    #array med lengder, boyestivheter og seksjonsmodul
    L  = lengder(punkt, elemkonn)                 
    EI = boyestivhet_fn(tvsnitt, e_mod, GEOMETRI)    
    W  = _seksjonsmodul_per_element(tvsnitt, GEOMETRI)

    # Bruk innsendte theta/M_fim hvis tilgjengelig, ellers default til null-arrays
    if theta_i is None:
        theta_i = np.zeros(nelem, dtype=float)
    else:
        theta_i = np.asarray(theta_i, dtype=float)

    if theta_j is None:
        theta_j = np.zeros(nelem, dtype=float)
    else:
        theta_j = np.asarray(theta_j, dtype=float)

    if M_fim_i is None:
        M_fim_i = np.zeros(nelem, dtype=float)
    else:
        M_fim_i = np.asarray(M_fim_i, dtype=float)

    if M_fim_j is None:
        M_fim_j = np.zeros(nelem, dtype=float)
    else:
        M_fim_j = np.asarray(M_fim_j, dtype=float)

  

    #beregner midt-moment for alle elementer med fordelt last
    #returnerer boyemoment_mid og noyemoment_u 
    res = boyemoment_fn(
        nelem=nelem,
        punkt=punkt,
        elemkonn=elemkonn,
        tvsnitt=tvsnitt,
        e_mod=e_mod,
        GEOMETRI=GEOMETRI,
        n_point_loads=n_point_loads,
        PUNKTLASTER=PUNKTLASTER,
        nel_loads=nel_loads,
        ELEMENTLASTER=ELEMENTLASTER,
        theta_i=theta_i, theta_j=theta_j,
        M_fim_i=M_fim_i, M_fim_j=M_fim_j,
        boyestivhet_fn=boyestivhet_fn,
        endemoment_fn=endemoment_fn,
    )

    #Definerer disse og setter lik null
    M_mid = None
    M_u = None

    # hvis funksjonen returnerer en tuple (M_mid, M_u), pakk ut begge
    if PUNKTLASTER == None:
        M_mid = np.asarray(res[0])
        
    else:
        M_mid = np.asarray(res[0])
        
        M_u = np.asarray(res[1])
    

    # endemomenter via endemoment_tot, element for element
    M_end = np.zeros((nelem, 2), dtype=float)
    for e in range(nelem):
        Mi, Mj = endemoment_fn(
            float(EI[e]), float(L[e]),
            float(theta_i[e]), float(theta_j[e]),
            float(M_fim_i[e]), float(M_fim_j[e]),
        )
        M_end[e, 0] = Mi
        M_end[e, 1] = Mj
    

    # σ = M / W (Pa) i tre snitt: venstre ende, midt/under, høyre ende 
    sigma = np.zeros((nelem, 4), dtype=float)
    sigma[:, 0] = M_end[:, 0] / W          # venstre ende
    sigma[:, 1] = M_mid / W  #spenning midten av bjelken under last
    sigma[:,2] = M_u/ W     #spenning rett under last       
    sigma[:, 3] = M_end[:, 1] / W          # høyre ende
    

    # pakker boyespenning, W og etiketter i dict
    labels = np.array(["venstre/ende", "midt","under","høyre/ende"], dtype=object)

    return {"sigma": sigma, "labels": labels, "W": W}


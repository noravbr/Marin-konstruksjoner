import numpy as np

def _I_ror(D, t):
    return (np.pi / 64.0) * (D**4 - (D - 2.0*t)**4)

def _I_Iprofil(h, tw, bf, tf):
    If = 2 * (bf * tf**3 / 12.0 + (bf * tf) * ((h/2.0 - tf/2.0)**2))
    Iw = (tw * (h - 2.0*tf)**3) / 12.0
    return If + Iw

#beregner bøyestivhet EI for alle elementer i modellen
def boyestivhet(tvsnitt, e_mod, geometri):
    nelem = len(tvsnitt)
    EI = np.zeros(nelem, dtype=float)

    if geometri is not None:
        # Ny stil: type-id per element + geometri-lookup
        for i in range(nelem):
            type_id = int(tvsnitt[i])
            if type_id not in geometri:
                raise KeyError(f"Mangler geometri for type_id={type_id} (element {i})")
            
            # Hent ut profil-kode og parametere fra geometrien
            profil = geometri[type_id]
            profil_kode = profil["kode"]
            params = profil["params"]

            if profil_kode == 1:  # Rør
                D, t = params[:2]
                I = _I_ror(D, t)
            elif profil_kode == 2:  # I-profil
                h, tw, bf, tf = params[:4]
                I = _I_Iprofil(h, tw, bf, tf)
            else:
                # sender feilmelding hvis profil koden ikke er i input filen
                raise ValueError(f"Ukjent profil-kode {profil_kode} for type_id {type_id} (element {i})")
            
            EI[i] = float(e_mod[i]) * float(I)
        return EI #kun for oppgave b! husk å fjerne denne linjen senere, returnerer vanligvis EI

  
    tv = np.asarray(tvsnitt, dtype=object)
    if tv.ndim == 1:
        # Hvis noen har gitt tvsnitt som 1D med bare type-id, må geometri brukes, feilmelding
        raise ValueError("boyestivhet: tvsnitt ser ut til å være 1D type-id. "
                         "Bruk geometri-argumentet: boyestivhet(tvsnitt, e_mod, geometri).")
    for i in range(nelem):
        ttype = int(tv[i][0])
        if ttype == 1:
            D = float(tv[i][1]); t = float(tv[i][2])
            I = _I_ror(D, t)
        elif ttype == 2:
            h = float(tv[i][1]); tw = float(tv[i][2]); bf = float(tv[i][3]); tf = float(tv[i][4])
            I = _I_Iprofil(h, tw, bf, tf)
        else:
            raise ValueError(f"Ukjent tverrsnittstype {ttype} (element {i})")
        EI[i] = float(e_mod[i]) * float(I)
    return EI

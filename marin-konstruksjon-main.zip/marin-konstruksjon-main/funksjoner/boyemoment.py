import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import numpy as np
from lengder import lengder


def boyemoment(
    nelem,               # int
    punkt,               # np.ndarray [npunkt, 3]
    elemkonn,            # np.ndarray [nelem, 2]
    tvsnitt,             # np.ndarray [nelem]
    e_mod,               # np.ndarray [nelem]
    GEOMETRI: dict,    
    # laster:
    n_point_loads: int,
    PUNKTLASTER: dict,   # {"elem_ids": int[], "q": float[], "avstandsforhold": float[]}
    nel_loads: int,
    ELEMENTLASTER: dict, # {"elem_ids": int[], "q": float[]}
    
    # valgfrie: enderotasjoner og FIM-bidrag (samme lengde som nelem)
    theta_i=None, theta_j=None, M_fim_i=None, M_fim_j=None,
    boyestivhet_fn=None,
    endemoment_fn=None,
):
    #Beregner bøyemoment ved definerte punkter for punkt- og fordelte laster
    boyemom_u = np.zeros(nelem, dtype=float)
    boyemom_m = np.zeros(nelem, dtype=float)

    nelem = elemkonn.shape[0]
    L = lengder(punkt, elemkonn)
    EI_e = boyestivhet_fn(tvsnitt, e_mod, GEOMETRI)

    
    # default-verdier hvis ikke gitt
    if theta_i is None: theta_i = np.zeros(nelem, dtype=float)
    if theta_j is None: theta_j = np.zeros(nelem, dtype=float)
    if M_fim_i is None: M_fim_i = np.zeros(nelem, dtype=float)
    if M_fim_j is None: M_fim_j = np.zeros(nelem, dtype=float)

    # Beregner boyemoment for Punktlaster 
    if n_point_loads > 0:
        for i in range(n_point_loads):
            e_id = int(PUNKTLASTER["elem_ids"][i])
            L_e  = float(L[e_id])
            a    = float(PUNKTLASTER["avstandsforhold"][i]) * L_e
            b    = L_e - a
            P    = float(PUNKTLASTER["q"][i])

            Mi, Mj = endemoment_fn(EI_e[e_id], L_e,
                                    theta_i[e_id], theta_j[e_id],
                                    M_fim_i[e_id], M_fim_j[e_id])

            # Moment rett under punktlast (x=a)
            M_under = Mi * ((1 - a)/L_e) + Mj * (a/L_e) + P * a * b / L_e

            boyemom_u[e_id] += M_under  # superposisjon hvis flere laster

            

    # Bergener boyemoment for jevnt fordelt last
    if nel_loads > 0:
        for i in range(nel_loads):
            e_id = int(ELEMENTLASTER["elem_ids"][i])
            L_e  = float(L[e_id])
            q    = float(ELEMENTLASTER["q"][i])

            Mi, Mj = endemoment_fn(EI_e[e_id], L_e,
                                    theta_i[e_id], theta_j[e_id],
                                    M_fim_i[e_id], M_fim_j[e_id])

            # Moment midt på bjelken
            M_mid   = (Mi + Mj)/2.0 + q * L_e**2 / 8.0

            boyemom_m[e_id] += M_mid

            

    return boyemom_u , boyemom_m


# skjaer.py
import numpy as np
from lengder import lengder

def skjaer(
    nelement,
    elemkonn,
    elementlengder,
    element_q=None,
    punktl_pr_elem=None,
    trapes_pr_elem=None,
    M_i=None,
    M_j=None,
):
    #Beregner skjærkraftverdier ved elementendene vha. superposisjon av bidrag fra
    #endemomenter, jevnt fordelt last (uniform og trapes) og punktlaster.

    Ls = np.asarray(elementlengder, dtype=float)
    if Ls.shape[0] != nelement:
        raise ValueError("elementlengder må ha lengde nelement")

    # hjelpefunksjoner for fleksibilitet
    def _get_from_map(m, e):
        if m is None:
            return None
        try:
            # dict-liknende
            return m[e]
        except Exception:
            try:
                arr = np.asarray(m)
                return arr[e]
            except Exception:
                return None

    # sikre endemomenter som arrays
    Mi = np.zeros(nelement, dtype=float) if M_i is None else np.asarray(M_i, dtype=float)
    Mj = np.zeros(nelement, dtype=float) if M_j is None else np.asarray(M_j, dtype=float)
    if Mi.shape[0] != nelement or Mj.shape[0] != nelement:
        raise ValueError("M_i og M_j må ha lengde nelement")

    Q = np.zeros((nelement, 2), dtype=float)

    for e in range(nelement):
        L = float(Ls[e])
        if L <= 0:
            raise ValueError(f"Element {e} har ikke positiv lengde L={L}")

        # Startbidrag fra endemomenter:
        # For en ren momentlinje M(x) = M_i + (M_j-M_i)x/L => V = dM/dx = (M_j - M_i)/L (konstant)
        shear_from_endmom = (Mj[e] - Mi[e]) / L
        Q[e, 0] += shear_from_endmom
        Q[e, 1] += shear_from_endmom

        # Jevnt (uniform) eller trapes/lineært fordelt last
        # Hvis trapes finnes for elementet, bruk q1,q2. Ellers bruk element_q (uniform q).
        tr = _get_from_map(trapes_pr_elem, e)
        if tr is not None:
            q1 = float(tr[0])
            q2 = float(tr[1])
            # Formel (fra dokument): Q1 = q1*L/3 + q2*L/6 ; Q2 = - (q2*L/3 + q1*L/6)
            Q1 = q1 * L / 3.0 + q2 * L / 6.0
            Q2 = - (q2 * L / 3.0 + q1 * L / 6.0)
            Q[e, 0] += Q1
            Q[e, 1] += Q2
        else:
            q = _get_from_map(element_q, e)
            if q is not None and float(q) != 0.0:
                qf = float(q)
                # uniform last = spesialtilfelle av linær (q1=q2=q): Q1 = q*L/2 , Q2 = -q*L/2
                Q[e, 0] += qf * L / 2.0
                Q[e, 1] += - qf * L / 2.0

        # Punktlaster (kan være flere for samme element)
        pls = _get_from_map(punktl_pr_elem, e)
        if pls:
            for item in pls:
                # forventet (P, a) eller [P, a]
                P = float(item[0])
                a_raw = float(item[1])
                # hvis a_raw i [0,1] tolkes som relativ posisjon
                if 0.0 <= a_raw <= 1.0:
                    a = a_raw * L
                else:
                    a = a_raw
                a = max(0.0, min(a, L))
                b = L - a
                #regener ut skjaerspenning
                Q[e, 0] += P * b / L
                Q[e, 1] += - P * a / L

    return Q

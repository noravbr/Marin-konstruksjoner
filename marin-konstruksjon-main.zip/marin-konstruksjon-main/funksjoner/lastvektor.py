import sys, os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

import numpy as np
from lesinput import lesinput

#lastvektor for et bjelkeelement er fastinnspenningsmomentene for et knutepunkt i hver ende av elementet

def fim(L, q=None, punktlaster=None, trapeslast = None):
   
    #L : Elementlengde [m]
    #q : float or None, Jevnt fordelt last [N/m], positiv nedover. None hvis ingen UDL.
    #punktlaster : list of (P, a) or None, Liste med punktlaster: P [N] (nedover positiv), a [m] målt fra venstre ende.
  
    #S_fim : [M_i, M_j] i elementets ender (i=venstre, j=høyre), fortegnskonvensjon sagging +
    M_i = 0.0
    M_j = 0.0

    # Jevnt fordelt last (UDL)
    if q is not None and q != 0.0:
        M_i += -(q * L**2 )/ 12.0
        M_j += (q * L**2 )/ 12.0

    # Punktlaster
    if punktlaster:
        for P, a in punktlaster:
            b = L - a
            # FIM for punktlast mellom ender
            M_i += -P * a * b**2 / L**2
            M_j += P * a**2 * b / L**2

    # Trapeslast
    if trapeslast is not None:
        # forventer trapeslast som (q1, q2)
        q1, q2 = trapeslast
        dq = q2 - q1
        jevnt_dq_i = -(dq * L**2 )/ 12.0
        jevnt_dq_j = (dq * L**2 )/ 12.0
        triangulær_last_i = -( (1.0/30) * dq * L**2 )
        triangulær_last_j = ( (1.0/20) * dq * L**2 )
        M_i += jevnt_dq_i + triangulær_last_i
        M_j += jevnt_dq_j + triangulær_last_j

    return np.array([M_i, M_j])


def elemlast_til_syslast(R, S_fim, elemkonn, e):
    # R : systemlastvektor (np.ndarray)
    # S_fim : elementlastvektor for element e (np.ndarray [M_i, M_j])
    # elemkonn : np.ndarray [nelem, 2]
    # e : element-id (int)
    i_node, j_node = elemkonn[e, 0], elemkonn[e, 1]
    R[i_node] += S_fim[0]
    R[j_node] += S_fim[1]
    return R

def knutmom(R, knut_momenter):
  
    #Legger til påsatte momenter direkte i knutepunkt.
    #Forventer alltid dict
    #knut_momenter = {"node_ids": array_like, "Mz": array_like}
  
    nodes = knut_momenter["node_ids"]
    Mz = knut_momenter["Mz"]
    for node, M in zip(nodes, Mz):
        R[int(node)] += float(M)
    return R


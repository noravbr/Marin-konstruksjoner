import numpy as np
#brukes for å lage momentdiagrammer og regne ut totale endemomenter
#setter delta = 0 når det er uforskyvelig ramme
def endemoment_per_elem(EI_e, L, theta_i, theta_j, M_fim_i, M_fim_j, delta = 0.0):
    """
    Totale endemomenter = ke*[theta_i, theta_j]^T + [M_fim_i, M_fim_j]^T
    fastinnspenningsmometet = [M_fim_i, M_fim_j]^T 343
    """
    #EI_e = bøyestivheten til element e
    #L = lengden til elementet
    #theta_i = rotasjon (vinkel) i startnode
    #theta_j = rotasjon i sluttnode
    #theta_j = rotasjon i sluttnode
    #M_fim_i = fast innspenningsmoment i startnode  
    #M_fim_j = fast innspenningsmoment i sluttnode
    
    #oppretter bjelkens lokale rotasjonsstivhetsmatrise
    ke = (EI_e / L) * np.array([[4.0, 2.0],
                                [2.0, 4.0]], dtype=float)

    #regner ut momentbidrag fra rotasjoner                                     
    M_rot = ke @ np.array([theta_i, theta_j], dtype=float)
    M_i, M_j = M_rot[0] + M_fim_i, M_rot[1] + M_fim_j
    return M_i, M_j


def endemoment(nelem, elemkonn, theta_i, theta_j, M_fim_i, M_fim_j, EI, elemlen):
    """
    Beregn endemomenter M_i og M_j for alle elementer uten bøyestivhet og lengde.
    Antar at elementene er uforskyvede (delta=0).
    """
    M_i = np.zeros(nelem, dtype=float)
    M_j = np.zeros(nelem, dtype=float)


    for i in range(nelem):
        L = elemlen[i]
        # Støtte for både array og skalar EI
        EI_e = np.array(EI)[i] if np.ndim(EI) > 0 else EI


        #oppretter bjelkens lokale rotasjonsstivhetsmatrise
        ke = (EI_e / L) * np.array([[4.0, 2.0],
                                   [2.0, 4.0]], dtype=float)


        # bruk element-spesifikke rotasjoner (theta_i og theta_j er arrays per element)
        theta_i_e = theta_i[i]
        theta_j_e = theta_j[i]


        moment1 = (ke[0][0] * theta_i_e + ke[0][1] * theta_j_e - M_fim_i[i])
        moment2 = (ke[1][0] * theta_i_e + ke[1][1] * theta_j_e - M_fim_j[i])


        M_i[i] = moment1
        M_j[i] = moment2
    return M_i, M_j
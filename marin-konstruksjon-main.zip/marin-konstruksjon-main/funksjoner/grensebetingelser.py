import numpy as np

# Innfører grensebetingelser i systemstivhetsmatrise K og lastvektor R
def bc(knutepunkt, nknutepunkt, K, R):
    
    Kn = K.copy()
    Rn = R.copy()

    # Finn alle knutepunkt som er fastholdt mot rotasjon

    for j in range(nknutepunkt):
        if int(knutepunkt[j, 2]) == 0:  # null rotasjon
            # tilhørende rad og kolonne nulles ut i stivhetsmatrisen
            Kn[j, :] = 0.0 
            Kn[:, j] = 0.0


            Kn[j, j] = 1  # diagonalen settes lik et vilkårlig tall, her 1
            Rn[j] = 0 #tilhørende element settes lik null i lastvektoren
    return Kn, Rn

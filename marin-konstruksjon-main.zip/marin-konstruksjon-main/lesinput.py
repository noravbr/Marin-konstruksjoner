import numpy as np
import warnings

# Valgfrie modul-variabler (tilgjengelig etter lesinput()).
GEOMETRI = {}
KNUTELASTER = {"node_ids": np.array([], dtype=int), "Mz": np.array([], dtype=float)}
fordelte_laster = {"elem_ids": np.array([], dtype=int), "q": np.array([], dtype=float)}

def lesinput(filename):   
    warnings.filterwarnings("ignore", category=UserWarning, module="numpy")

     #Leser og fjerner innommentarer, tomme linjer, for å ikke få noe error på dette

    def _clean_tokens(line: str):
        #Fjerner kommentarer og splitter linje i tokens
        s = line.split("#", 1)[0].strip()
        if not s:
            return None
        return [t.replace(",", ".") for t in s.split()]

    with open(filename, "r", encoding="utf-8") as f:  
        raw_lines = f.readlines()

    # tokens med original linjenummer (for tydelig feilmelding)
    toks = []
    for idx, ln in enumerate(raw_lines, start=1):
        t = _clean_tokens(ln)
        if t:
            toks.append((idx, t))

    i = 0  # peker i toks-listen

    #Funksjoner for lesing og konvertering, til int osv.

    def _need(count: int, where: str):
        """Sjekk at det finnes count rader igjen."""
        nonlocal i
        if i + count > len(toks):
            raise ValueError(
                f"{where}: forventet {count} rader, men fant bare {len(toks) - i}."
            )

    def _as_int(s: str) -> int:
        return int(float(s))

    def _as_num(s: str) -> float:
        #Tall/uttrykk som tåler 210e9, 29/3, 355*10**6
        return float(eval(s, {"_builtins_": {}}, {}))

    def _read_count(name: str) -> int:
        #"Les en enkelt heltallsteller (på én linje)
        nonlocal i
        if i >= len(toks):
            raise ValueError(f"{name}: mangler teller-linje.")
        ln, row = toks[i]
        i += 1
        try:
            return _as_int(row[0])
        except Exception:
            raise ValueError(f"{name}: teller på linje {ln} er ikke et heltall: {row[0]!r}")

    def _read_block_exact(n: int, min_cols: int, name: str):
        #leser n rader med minst min_cols kolonner
        nonlocal i
        _need(n, name)
        block = toks[i : i + n]
        # valider kolonneantall
        for ln, row in block:
            if len(row) < min_cols:
                raise ValueError(
                    f"{name}: rad på linje {ln} har for få kolonner "
                    f"(minst {min_cols} kreves), fant: {row}"
                )
        i += n
        return block

    # Leser seksjoner i ønsket rekkefølge

    # Knutepunkt
    # leser antall knutepunk <npunkt>
    npunkt = _read_count("Knutepunkt (antall)")
    #leser npunkt rader: x, y , fastholdt/fri rotasjon=0,1
    punkt_blk = _read_block_exact(npunkt, 3, "Knutepunkt-tabell")
    # lager numpy-array
    punkt = np.array([[ _as_int(c[0]), _as_int(c[1]), _as_int(c[2]) ] for _, c in punkt_blk], dtype=int)

    # Elementer
    # leser antall elementer <nelem>
    nelem = _read_count("Elementer (antall)")
     #leser nelem rader:  Systemfrihetsgrad for lokal frihetsgrad 1, Systemfrihetsgrad for lokal ende 2, Elastisitetsmodul, Profiltype (1 = rør 2= I profil)
    elem_blk = _read_block_exact(nelem, 4, "Element-tabell")
    
    # lager numpy-arrays
    n1_list, n2_list, e_list, tvs_list = [], [], [], []
    for ln, c in elem_blk:
        try:
            n1 = _as_int(c[0]); n2 = _as_int(c[1])
            E  = _as_num(c[2])
            tv = _as_int(c[3])  # i ditt oppsett er profiltype 1/2
        except Exception as e:
            raise ValueError(f"Element-tabell: ugyldig verdi på linje {ln}: {c} ({e})")
        n1_list.append(n1); n2_list.append(n2); e_list.append(E); tvs_list.append(tv)
   
    #lager egne numpy-arrays for elemkonn, e_mod, tvsnitt, med rikittig navn
    elemkonn = np.column_stack([n1_list, n2_list]).astype(int)
    e_mod    = np.array(e_list, dtype=float)
    tvsnitt  = np.array(tvs_list, dtype=int)

    # Tverrsnittstyper (GEOMETRI)
    # leser antall tversnitt <ngeom>
    ngeom = _read_count("Tverrsnittstyper (antall)")
    #leser ngeom rader: type_id, parametre...
    geom_blk = _read_block_exact(ngeom, 2, "Tverrsnittstyper-tabell")
    
    geo = {}
    for ln, c in geom_blk:
        try:
            type_id = _as_int(c[0])
            kode = _as_int(c[1])
            params = [_as_num(p) for p in c[2:]]

            # Validering...
            if kode == 1 and len(params) < 2:
                raise ValueError(f"Rør-profil (kode 1) krever 2 parametere (D, t), fant {len(params)}")
            elif kode == 2 and len(params) < 4:
                raise ValueError(f"I-profil (kode 2) krever 4 parametere (h, tw, bf, tf), fant {len(params)}")
            elif kode not in [1, 2]:
                raise ValueError(f"Ukjent profil-kode {kode}. Må være 1 (rør) eller 2 (I-profil).")

            # Lagre både kode og params for hver type_id
            geo[type_id] = {"kode": kode, "params": params}

        except ValueError as e:
            raise ValueError(f"Tverrsnittstyper-tabell: feil på linje {ln}: {e}")
        except Exception as e:
            raise ValueError(f"Tverrsnittstyper-tabell: uventet feil på linje {ln} for rad {c}: {e}")

    # lager GEOMETRI- variabel globalt
    global GEOMETRI
    GEOMETRI = geo

    # Knutelaster
    # leser antall knutelaster <nnode_loads>
    nnode_loads = _read_count("Knutelaster (antall)")
    #leser nnode_loads rader: node_id , Mz
    nl_blk = _read_block_exact(nnode_loads, 2, "Knutelaster-tabell") if nnode_loads > 0 else []
    #lager numpy-arrays
    if nnode_loads > 0:
        node_ids, Mz = [], []
        for ln, c in nl_blk:
            try:
                node_ids.append(_as_int(c[0]))
                Mz.append(_as_num(c[1]))
            except Exception as e:
                raise ValueError(f"Knutelaster: ugyldig rad på linje {ln}: {c} ({e})")
        #lager global variabel
        global KNUTELASTER
        KNUTELASTER = {"node_ids": np.array(node_ids, dtype=int), "Mz": np.array(Mz, dtype=float)}

    # Elementlaster (jevnt fordelt q)
    # leser antall jevntfordelt laster <nel_loads>
    nel_loads = _read_count("Elementlaster (antall)")
    #leser nel_loads rader: elem_id q
    el_blk = _read_block_exact(nel_loads, 2, "Elementlaster-tabell") if nel_loads > 0 else []
    if nel_loads > 0:
        elem_ids, qs = [], []
        for ln, c in el_blk:
            try:
                elem_ids.append(_as_int(c[0]))
                qs.append(_as_num(c[1]))
            except Exception as e:
                raise ValueError(f"Elementlaster: ugyldig rad på linje {ln}: {c} ({e})")
        #lager global variabel
        global ELEMENTLASTER
        ELEMENTLASTER = {"elem_ids": np.array(elem_ids, dtype=int), "q": np.array(qs, dtype=float)}

    # Punktlaster
    # leser antall punktlaster <n_point_loads>
    n_point_loads = _read_count("Punktlaster (antall)")
    # leser n_point_loads rader: elem_id , q , avstandsforhold
    pl_blk = _read_block_exact(n_point_loads, 3, "Punktlaster-tabell") if n_point_loads > 0 else []
    #lager numpy-arrays
    if n_point_loads > 0:
        eids, qv, avs = [], [], []
        for ln, c in pl_blk:
            try:
                eids.append(_as_int(c[0]))
                qv.append(_as_num(c[1]))
                avs.append(_as_num(c[2]))
            except Exception as e:
                raise ValueError(f"Punktlaster: ugyldig rad på linje {ln}: {c} ({e})")
        PUNKTLASTER = {
            "elem_ids": np.array(eids, dtype=int),
            "q": np.array(qv, dtype=float),
            "avstandsforhold": np.array(avs, dtype=float),
        }
    # lager ellers tomme arrays
    else:
        PUNKTLASTER = {
            "elem_ids": np.array([], dtype=int),
            "q": np.array([], dtype=float),
            "avstandsforhold": np.array([], dtype=float),
        }

    # Trapeslaster
    # leser antall trapeslaster <n_trap_loads>
    n_trap_loads = _read_count("Trapeslaster (antall)")
    # leser n_trap_loads rader: elem_id,  q1 , q2
    tl_blk = _read_block_exact(n_trap_loads, 3, "Trapeslaster-tabell") if n_trap_loads > 0 else []
    if n_trap_loads > 0:
        eids, q1s, q2s = [], [], []
        for ln, c in tl_blk:
            try:
                eids.append(_as_int(c[0]))
                q1s.append(_as_num(c[1]))
                q2s.append(_as_num(c[2]))
            except Exception as e:
                raise ValueError(f"Trapeslaster: ugyldig rad på linje {ln}: {c} ({e})")
        TRAPESLASTER = {
            "elem_ids": np.array(eids, dtype=int),
            "q1": np.array(q1s, dtype=float),
            "q2": np.array(q2s, dtype=float),
        }
    #lager ellers tomme arrays
    else:
        TRAPESLASTER = {
            "elem_ids": np.array([], dtype=int),
            "q1": np.array([], dtype=float),
            "q2": np.array([], dtype=float),
        }

    # Flytespenning
    # leser antall flytespenninger <n_flyt> 
    n_flyt = _read_count("Flytespenning (antall)")
    # leser n_flyt rader: flytespenning-verdi og lagrer enkeltverdi
    if n_flyt > 0:
        _need(1, "Flytespenning-verdi")
        ln, row = toks[i]; i += 1
        try:
            FLYTESPENNING = _as_num(row[0])
        except Exception as e:
            raise ValueError(f"Flytespenning: ugyldig verdi på linje {ln}: {row} ({e})")
    else:
        FLYTESPENNING = None

    #  Returner all data

    return (
        npunkt,
        punkt,
        nelem,
        elemkonn,
        tvsnitt,
        e_mod,
        nnode_loads,
        KNUTELASTER,
        nel_loads,
        ELEMENTLASTER,
        n_point_loads,
        PUNKTLASTER,
        n_trap_loads,
        TRAPESLASTER,
        n_flyt,
        FLYTESPENNING,
        GEOMETRI
    )
#main for deabugging og testing


if __name__ == "__main__":
    (
        npunkt, punkt, nelem, elemkonn, tvsnitt, e_mod,
        nnode_loads, KNUTELASTER, nel_loads, ELEMENTLASTER,
        n_point_loads, PUNKTLASTER, n_trap_loads, TRAPESLASTER,
        n_flyt, FLYTESPENNING, GEOMETRI
    ) = lesinput("input.txt")

    ok = True

    # Konsistens: antall rader = teller
    if punkt.shape[0] != npunkt:
        print(f"[FEIL] npunkt={npunkt}, men punkt-rader={punkt.shape[0]}")
        ok = False
    if elemkonn.shape[0] != nelem:
        print(f"[FEIL] nelem={nelem}, men elemkonn-rader={elemkonn.shape[0]}")
        ok = False
    if tvsnitt.shape[0] != nelem:
        print(f"[FEIL] tvsnitt-lengde={tvsnitt.shape[0]}, forventet {nelem}")
        ok = False
    if e_mod.shape[0] != nelem:
        print(f"[FEIL] e_mod-lengde={e_mod.shape[0]}, forventet {nelem}")
        ok = False

    # Valgfrie seksjoner: teller vs faktisk lest
    if nnode_loads != KNUTELASTER["node_ids"].size:
        print(f"[FEIL] Knutelaster: deklarert={nnode_loads}, lest={KNUTELASTER['node_ids'].size}")
        ok = False
    if nel_loads != ELEMENTLASTER["elem_ids"].size:
        print(f"[FEIL] Elementlaster: deklarert={nel_loads}, lest={ELEMENTLASTER['elem_ids'].size}")
        ok = False
    if n_point_loads != PUNKTLASTER["elem_ids"].size:
        print(f"[FEIL] Punktlaster: deklarert={n_point_loads}, lest={PUNKTLASTER['elem_ids'].size}")
        ok = False
    if n_trap_loads != TRAPESLASTER["elem_ids"].size:
        print(f"[FEIL] Trapeslaster: deklarert={n_trap_loads}, lest={TRAPESLASTER['elem_ids'].size}")
        ok = False
    if (n_flyt > 0) and (FLYTESPENNING is None):
        print(f"[FEIL] Flytespenning: deklarert={n_flyt}, men ingen verdi lest")
        ok = False

    # Sammendrag
    print("\n=== TEST AV lesinput() ===")
    print(f"Knutepunkt (npunkt)      : {npunkt}")
    print(f"Elementer (nelem)        : {nelem}")
    print(f"Unike tverrsnittstyper   : {len(set(tvsnitt.tolist()))}")
    print(f"Knutelaster              : {nnode_loads} rad(er)")
    print(f"Elementlaster (q)        : {nel_loads} rad(er)")
    print(f"Punktlaster              : {n_point_loads} rad(er)")
    print(f"Trapeslaster             : {n_trap_loads} rad(er)")
    print(f"Flytespenning (n/verdi)  : {n_flyt} / {FLYTESPENNING}")

    # Vis litt data
    np.set_printoptions(suppress=True, linewidth=120)
    print("\n— Første 5 knutepunkt [x, y, fix_rz] —")
    print(punkt[:5])
    print("\n— Første 5 element-konnektivitet [n1, n2] —")
    print(elemkonn[:5])
    print("\n— Første 10 tvsnitt (type-id per element) —")
    print(tvsnitt[:10])
    print("\n— Første 10 E-moduler [Pa] —")
    print(e_mod[:10])

    if KNUTELASTER["node_ids"].size:
        print("\n— Knutelaster (node_id → Mz) —")
        for nid, mz in zip(KNUTELASTER["node_ids"], KNUTELASTER["Mz"]):
            print(f"  node {int(nid)} : Mz = {mz}")

    if ELEMENTLASTER["elem_ids"].size:
        print("\n— Elementlaster (elem_id → q) —")
        for eid, q in zip(ELEMENTLASTER["elem_ids"], ELEMENTLASTER["q"]):
            print(f"  elem {int(eid)} : q = {q}")

    if PUNKTLASTER["elem_ids"].size:
        print("\n— Punktlaster (elem_id → q, a/L) —")
        for eid, q, afr in zip(PUNKTLASTER["elem_ids"], PUNKTLASTER["q"], PUNKTLASTER["avstandsforhold"]):
            print(f"  elem {int(eid)} : q = {q}, a/L = {afr}")

    if TRAPESLASTER["elem_ids"].size:
        print("\n— Trapeslaster (elem_id → q1, q2) —")
        for eid, q1, q2 in zip(TRAPESLASTER["elem_ids"], TRAPESLASTER["q1"], TRAPESLASTER["q2"]):
            print(f"  elem {int(eid)} : q1 = {q1}, q2 = {q2}")

    print("\nSTATUS:", "OK " if ok else "FEIL OPPDAGET ")